
OB (ONURCAN BULAK) -Statik Kod Analiz Hata Bulma Aracı  

Bu araç, Python projeleri için güvenlik, sürdürülebilirlik ve en iyi uygulamalar üzerine odaklanan bir statik kod analiz çözümüdür. Araç, döngüsel karmaşıklık, fonksiyon uzunluğu, eksik açıklama metinleri (docstring), güvenlik açıkları ve daha fazlası gibi bir dizi yerleşik kural içerir. Python dosyalarını analiz ederek potansiyel sorunları içeren ayrıntılı bir JSON raporu üretir.

Özellikler
Döngüsel Karmaşıklık Analizi: Yüksek karmaşıklığa sahip fonksiyonları tespit eder.
Fonksiyon Uzunluğu Kontrolü: Fonksiyonların belirli bir uzunluğu aştığı durumlarda uyarır.
Eksik Docstring Algılama: Docstring bulunmayan fonksiyonları işaretler.
Kullanılmayan Değişken Tespiti: Atanan ancak kullanılmayan değişkenleri belirler.
Değişken Adlandırma Kurallarını Zorlama: Değişkenlerin snake_case adlandırma kuralına uygun olup olmadığını kontrol eder.
Güvenlik Açığı Tespiti: eval, exec gibi tehlikeli fonksiyonların kullanımını ve potansiyel SQL enjeksiyonu risklerini işaretler.
Başlarken
Gereksinimler
Python 3.x: Araç, Python 3 veya daha üst bir sürüm gerektirir.
Gerekli Python paketlerini yüklemek için şu komutu çalıştırın:
bash



  ```bash
  pip install -r requirements.txt
  ```

### Project Yapısı
```
static_code_analysis_tool/
│
├── main.py                         # Analizi çalıştırmak için ana dosya
├── parsers/                        # Python dosyaları için AST ayrıştırıcıları
│   └── python_parser.py
├── reports/                        # Rapor oluşturma mantığı
│   ├── report.py                   # Rapor yapısını tanımlar
│   └── report_generator.py         # JSON raporları oluşturur
├── rule_engine/                    # Statik analiz için tüm kurallar
│   ├── cyclomatic_complexity_rule.py
│   ├── function_length_rule.py
│   ├── missing_docstring_rule.py
│   ├── rule_executor.py            # Kuralların çalıştırılmasını sağlar
│   ├── rule_manager.py             # Tüm kuralları yönetir ve uygular
│   ├── security_vulnerability_rule.py
│   ├── unused_variable_rule.py
│   └── variable_naming_rule.py
├── tests/                          # Test dosyaları
│   └── integrated_test_1_rule.py
│   └── test_code_sample1_rule.py
└── requirements.txt                # Gerekli Python paketleri

```

### Kullanım

1. **Analiz edilecek Python dosyalarını ekleyin:**:
   Analiz etmek istediğiniz .py dosyalarını tests/ klasörüne yerleştirin.

2. **Analizi çalıştırın:**:
   main.py dosyasını çalıştırarak tests/ klasöründeki tüm Python dosyalarını analiz edin.
    ```bash
   python main.py
   ```

3. **Oluşturulan raporu inceleyin**:
     Analiz sonuçları 'report.json' dosyasına kaydedilir. Bu rapor, koddaki tüm uyarı ve sorunları içerir.

### Örnek Rapor (`report.json`):
```json
[
    {
        "file_name": "test_cyclomatic.py",
        "rule_type": "cyclomatic_complexity",
        "message": "Function 'complex_function' has high cyclomatic complexity (7).",
        "line_number": 1
    },
    {
        "file_name": "test_docstring.py",
        "rule_type": "missing_docstring",
        "message": "Function 'my_function' is missing a docstring.",
        "line_number": 3
    }
]
```

### Yeni Kurallar Ekleme
To add new rules:
1. `rule_engine/`dizininde yeni bir Python dosyası oluşturun.
2. AST'i işlemek ve gerektiğinde uyarılar oluşturmak için `apply()` metodunu uygulayın.
3. Yeni Kuralı  `DynamicRuleManager` a ekleyerek analize dahil edin.

Copyright (C) 2024 Onurcan BULAK