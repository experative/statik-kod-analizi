import os
import concurrent.futures
from parsers.python_parser import ASTParser
from rule_engine.rule_manager import DynamicRuleManager
from reports.report_generator import JSONReportGenerator
from reports.report import Report

# Belirli bir dosyayı analiz eden fonksiyon
def analyze_file(file_path):
    # Dosyayı okuma
    with open(file_path, 'r') as file:
        source_code = file.read()

    # Kodun AST'ye (Abstract Syntax Tree - Soyut Sözdizim Ağacı) dönüştürülmesi
    ast_tree = ASTParser.parse_code(source_code)
    if ast_tree is None:  # Eğer AST oluşturulamıyorsa, boş liste döndür
        return []

    # Kuralları yönetecek dinamik kural yöneticisi
    rule_manager = DynamicRuleManager('rule_engine')
    file_name = os.path.basename(file_path)  # Dosya adını al

    # Her dosya için yerel bir rapor oluşturucu
    local_report_generator = JSONReportGenerator()

    # AST üzerinde kuralları uygula
    rule_manager.apply_rules(ast_tree, file_name, local_report_generator)

    # Dosya için oluşturulan raporları döndür
    return local_report_generator.reports

# Ana program fonksiyonu
def main():
    # Yalnızca 'verilen dosyanın' dosyasını analiz etmek için dosya yolunu belirtin
    file_paths = ['tests/integrated_test_1_rule.py']  # Yalnızca bu dosya analiz edilecek

    # Paralel olarak analiz işlemi gerçekleştir
    with concurrent.futures.ProcessPoolExecutor() as executor:
        all_reports = list(executor.map(analyze_file, file_paths))

    # Tüm raporları tek bir listeye düzleştir
    flattened_reports = [report for file_reports in all_reports for report in file_reports]

    # Nihai rapor oluşturucu ve tüm raporları ekleme
    final_report_generator = JSONReportGenerator()
    for report_dict in flattened_reports:
        # Her bir rapor için Report sınıfını kullanarak rapor nesnesi oluştur
        report = Report(**report_dict)
        final_report_generator.add_report(report)

    # Son raporu JSON formatında oluştur
    final_report_generator.generate()

# Programın çalıştırılması
if __name__ == "__main__":
    main()
