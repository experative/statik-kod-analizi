import ast  # Python'un soyut sözdizim ağacı modülünü içeri aktarıyoruz.

class ASTParser:
    @staticmethod
    def parse_code(source_code):
        try:
            return ast.parse(source_code)  # Kaynak kodu soyut sözdizim ağacına dönüştürür.
        except SyntaxError as e:  # Sözdizimi hatası durumunda hata yakalanır.
            print(f"Kaynak koda ilişkin sözdizimi hatası: {e}")  # Hata mesajını yazdırır.
            return None  # Hata durumunda None döner.
