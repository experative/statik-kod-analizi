class Report:
    def __init__(self, file_name, rule_type, message, line_number=None):
        """
        Rapor nesnesinin oluşturulması için gerekli bilgiler:
        - Dosya adı, kural tipi, mesaj ve satır numarası.
        """
        self.file_name = file_name  # Dosya adı
        self.rule_type = rule_type  # Kural tipi
        self.message = message  # Mesaj
        self.line_number = line_number  # Satır numarası (isteğe bağlı)

    def to_dict(self):
        """
        Raporu sözlük formatına dönüştürür.
        """
        report = {
            "file_name": self.file_name,  # Dosya adı
            "rule_type": self.rule_type,  # Kural tipi
            "message": self.message  # Mesaj
        }
        if self.line_number is not None:  # Satır numarası varsa ekler.
            report["line_number"] = self.line_number
        return report  # Sözlüğü döner.

    @classmethod
    def from_dict(cls, report_dict):
        """
        Sözlükten rapor nesnesi oluşturur.
        """
        return cls(**report_dict)  # Sözlükteki değerlerle nesneyi oluşturur.
