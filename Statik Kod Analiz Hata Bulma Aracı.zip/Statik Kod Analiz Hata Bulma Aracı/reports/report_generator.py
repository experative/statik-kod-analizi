import json  # JSON verilerini işlemek için kullanılan modül.

class JSONReportGenerator:
    def __init__(self):
        self.reports = []  # Raporları tutacak liste.

    def add_report(self, report):
        """
        Raporu listeye ekler.
        """
        self.reports.append(report.to_dict())  # Raporu sözlük formatında listeye ekler.

    def generate(self, filename='report.json'):
        """
        Raporları JSON formatında dışa aktarır.
        """
        with open(filename, 'w') as report_file:  # Belirtilen dosyaya yazmak için açar.
            json.dump(self.reports, report_file, indent=4)  # Listeyi JSON formatında dosyaya yazar.

    def print_report(self):
        """
        Hata ayıklama amacıyla raporları ekrana yazdırır.
        """
        for report in self.reports:  # Listeyi dolaşır.
            print(report)  # Raporları ekrana yazdırır.
