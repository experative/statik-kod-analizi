import ast  # Python kodunun soyut sözdizim ağacını (AST - Abstract Syntax Tree) incelemek için kullanılan bir modül.
from reports.report import Report  # Raporlama işlemleri için kullanılan bir sınıf.

# Çevrimsel Karmaşıklık Kuralı sınıfı
class CyclomaticComplexityRule:
    def __init__(self, threshold=5):
        """
        Sınıfın yapıcı metodu.
        threshold: Karmaşıklık için eşik değeri (varsayılan: 5). 
        Bu değeri aşan fonksiyonlar "aşırı karmaşık" olarak işaretlenir.
        """
        self.threshold = threshold

    def apply(self, ast_tree, file_name, report_generator):
        """
        Belirtilen soyut sözdizim ağacını analiz eder.
        Her bir fonksiyonun karmaşıklığını hesaplar ve belirlenen eşik değerini aşanlar için uyarılar oluşturur.

        Parametreler:
        - ast_tree: Analiz edilecek soyut sözdizim ağacı.
        - file_name: Hangi dosyanın analiz edildiğini belirtir.
        - report_generator: Rapor oluşturmak için kullanılan nesne.
        """

        def calculate_complexity(node, depth=0):
            """
            Belirtilen düğümün çevrimsel karmaşıklığını hesaplar.

            - For, While veya ExceptHandler yapıları bulunduğunda karmaşıklık artırılır.
            - If yapısı ve varsa else/elif blokları karmaşıklığı artırır.
            - Mantıksal ifadelerde (ör. and, or), koşul sayısı kadar karmaşıklık eklenir.

            Parametreler:
            - node: AST düğümü (soyut sözdizim ağacındaki bir yapı).
            - depth: Düğümün analiz derinliği. (İç içe yapılar için takip edilir.)
            
            Geri dönüş:
            - complexity: Düğümün toplam çevrimsel karmaşıklık değeri.
            """
            complexity = 1 if depth == 0 else 0  # Ana fonksiyon için başlangıç karmaşıklık değeri 1'dir.
            for child in ast.iter_child_nodes(node):  # Mevcut düğümün alt düğümlerini (child nodes) inceler.
                # Eğer bir döngü (for, while) veya hata yakalama bloğu (except) varsa karmaşıklık artırılır.
                if isinstance(child, (ast.For, ast.While, ast.ExceptHandler)):
                    complexity += 1
                elif isinstance(child, ast.If):  # Koşullu ifadelerde karmaşıklık artırılır.
                    complexity += 1
                    if child.orelse:  # Eğer bir 'else' veya 'elif' varsa karmaşıklık artırılır.
                        complexity += 1
                elif isinstance(child, ast.BoolOp):  # Mantıksal işlemler (and, or) için karmaşıklık artırılır.
                    complexity += len(child.values) - 1

                # Eğer düğüm bir fonksiyon değilse, alt düğümler üzerinde tekrar karmaşıklık hesaplanır.
                if not isinstance(child, ast.FunctionDef):
                    child_complexity = calculate_complexity(child, depth + 1)
                    complexity += child_complexity
            return complexity

        # Soyut sözdizim ağacındaki her düğümü dolaşır.
        for node in ast.walk(ast_tree):
            if isinstance(node, ast.FunctionDef):  # Yalnızca fonksiyon tanımlarını inceler.
                complexity = calculate_complexity(node)  # Fonksiyonun karmaşıklığını hesaplar.
                if complexity > self.threshold:  # Eğer karmaşıklık eşik değerini aşarsa:
                    # Uyarı mesajı oluşturulur.
                    warning_message = f"Fonksiyon '{node.name}' aşırı çevrimsel karmaşıklığa sahip ({complexity})."
                    print(warning_message)  # Uyarı konsola yazdırılır.

                    # Rapor oluşturulur ve raporlayıcıya eklenir.
                    report = Report(
                        file_name=file_name,
                        rule_type="cyclomatic_complexity",
                        message=warning_message,
                        line_number=node.lineno
                    )
                    report_generator.add_report(report)  # Rapor nesnesi rapor oluşturucusuna eklenir.
