import ast  # Python kodunun soyut sözdizim ağacını (AST - Abstract Syntax Tree) incelemek için kullanılan bir modül.
from reports.report import Report  # Raporlama işlemleri için kullanılan bir sınıf.

# Fonksiyon Uzunluğu Kuralı sınıfı
class FunctionLengthRule:
    def __init__(self, max_lines=10):
        """
        Sınıfın yapıcı metodu.
        max_lines: Bir fonksiyonun izin verilen maksimum satır sayısını belirtir (varsayılan: 10).
        Bu değeri aşan fonksiyonlar "çok uzun" olarak işaretlenir.
        """
        self.max_lines = max_lines

    def apply(self, ast_tree, file_name, report_generator):
        """
        Belirtilen soyut sözdizim ağacını analiz eder.
        Her bir fonksiyonun uzunluğunu (satır sayısını) kontrol eder ve eşik değeri aşan fonksiyonlar için uyarılar oluşturur.

        Parametreler:
        - ast_tree: Analiz edilecek soyut sözdizim ağacı.
        - file_name: Hangi dosyanın analiz edildiğini belirtir.
        - report_generator: Rapor oluşturmak için kullanılan nesne.
        """
        # Soyut sözdizim ağacındaki tüm düğümleri (node) dolaşır.
        for node in ast.walk(ast_tree):
            if isinstance(node, ast.FunctionDef):  # Yalnızca fonksiyon tanımlarını inceler.
                # Fonksiyonun başlangıç satırı ile bitiş satırı arasındaki fark hesaplanır.
                function_length = (node.end_lineno or 0) - (node.lineno or 0) + 1
                if function_length > self.max_lines:  # Eğer fonksiyonun uzunluğu eşik değeri aşarsa:
                    # Uyarı mesajı oluşturulur.
                    warning_message = f"Fonksiyon '{node.name}' çok uzun ({function_length} satır)."
                    print(warning_message)  # Uyarı konsola yazdırılır.

                    # Rapor oluşturulur ve raporlayıcıya eklenir.
                    report = Report(
                        file_name=file_name,
                        rule_type="function_length",
                        message=warning_message,
                        line_number=node.lineno
                    )
                    report_generator.add_report(report)  # Rapor nesnesi rapor oluşturucusuna eklenir.
