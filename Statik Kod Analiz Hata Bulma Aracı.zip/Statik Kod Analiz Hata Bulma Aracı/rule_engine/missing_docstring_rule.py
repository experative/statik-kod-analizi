import ast  # Python kodunun soyut sözdizim ağacını (AST - Abstract Syntax Tree) incelemek için kullanılan bir modül.
from reports.report import Report  # Raporlama işlemleri için kullanılan bir sınıf.

# Eksik Dokümantasyon (Docstring) Kuralı sınıfı
class MissingDocstringRule:
    def apply(self, ast_tree, file_name, report_generator):
        """
        Soyut sözdizim ağacını (AST) analiz ederek, dokümantasyon yazısı (docstring) olmayan
        fonksiyonları tespit eder ve uyarılar oluşturur.

        Parametreler:
        - ast_tree: Analiz edilecek soyut sözdizim ağacı.
        - file_name: Analiz edilen dosyanın adı.
        - report_generator: Rapor oluşturmak için kullanılan nesne.
        """
        # Soyut sözdizim ağacındaki tüm düğümleri dolaşır.
        for node in ast.walk(ast_tree):
            if isinstance(node, ast.FunctionDef):  # Yalnızca fonksiyon tanımlarını inceler.
                # Fonksiyonun dokümantasyon yazısı olup olmadığını kontrol eder.
                docstring = ast.get_docstring(node)
                if docstring is None or not docstring.strip():  # Eğer dokümantasyon eksikse:
                    # Uyarı mesajı oluşturulur.
                    warning_message = f"Uyarı: Fonksiyon '{node.name}' için dokümantasyon (docstring) eksik."
                    print(warning_message)  # Uyarı konsola yazdırılır.

                    # Rapor oluşturulur ve raporlayıcıya eklenir.
                    report = Report(
                        file_name=file_name,
                        rule_type="missing_docstring",
                        message=warning_message,
                        line_number=node.lineno
                    )
                    report_generator.add_report(report)  # Rapor nesnesi rapor oluşturucusuna eklenir.
