from reports.report import Report  # Rapor oluşturmak için kullanılan sınıf.

# Kural Yürütücü (Rule Executor) sınıfı
class RuleExecutor:
    def __init__(self, report_generator, file_name):
        """
        Sınıfın yapıcı metodu.
        - report_generator: Raporlama işlemlerini yöneten nesne.
        - file_name: Analiz edilen dosyanın adı.
        """
        self.report_generator = report_generator
        self.file_name = file_name

    def execute_rule(self, rule, ast_tree):
        """
        Belirtilen kuralı (rule) soyut sözdizim ağacı üzerinde çalıştırır.
        Kuralların uygulanması sırasında oluşabilecek hataları yakalar ve raporlar.

        Parametreler:
        - rule: Uygulanacak kural nesnesi.
        - ast_tree: Analiz edilecek soyut sözdizim ağacı (AST).
        """
        try:
            # Kuralı uygular ve gerekli parametreleri iletir.
            rule.apply(ast_tree, self.file_name, self.report_generator)
        except Exception as e:
            # Eğer bir hata oluşursa, hatayı yakalar ve bir hata raporu oluşturur.
            error_message = f"Kural '{rule.__class__.__name__}' çalıştırılırken bir hata oluştu: {str(e)}"
            print(error_message)  # Hata mesajını konsola yazdırır.
            
            # Hata raporunu oluşturur ve raporlayıcıya ekler.
            report = Report(
                file_name=self.file_name,
                rule_type=rule.__class__.__name__,
                message=error_message
            )
            self.report_generator.add_report(report)  # Hata raporunu rapor oluşturucusuna ekler.
