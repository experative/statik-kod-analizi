import importlib  # Modül ve sınıfları dinamik olarak yüklemek için kullanılan modül.
import os  # Dosya ve dizin işlemleri için kullanılan modül.
from rule_engine.rule_executor import RuleExecutor  # Kuralları çalıştırmak için kullanılan sınıf.

# Dinamik Kural Yöneticisi sınıfı
class DynamicRuleManager:
    def __init__(self, rule_directory):
        """
        Yapıcı metot:
        - rule_directory: Kuralların bulunduğu dizin.
        """
        self.rules = []  # Yüklenecek kuralları tutan liste.
        self.load_rules(rule_directory)  # Kuralları yükleme işlemini başlatır.

    def load_rules(self, rule_directory):
        """
        Belirtilen dizindeki kuralları dinamik olarak yükler.

        - rule_directory: Kuralların bulunduğu dizin.
        """
        # Kural dosyalarını listele ve yükle
        for file in os.listdir(rule_directory):
            if file.endswith('_rule.py') and file != '__init__.py':  # Sadece '_rule.py' ile biten dosyaları yükler.
                module_name = file[:-3]  # '.py' uzantısını kaldır.
                try:
                    # Modülü dinamik olarak içe aktar.
                    rule_module = importlib.import_module(f'rule_engine.{module_name}')
                    # Sınıf adını oluştur ('snake_case' -> 'PascalCase').
                    rule_class_name = module_name.replace('_', ' ').title().replace(' ', '')
                    # Sınıfı yükle ve örneğini oluştur.
                    rule_class = getattr(rule_module, rule_class_name)
                    self.rules.append(rule_class())  # Kurallar listesine ekle.
                except (ImportError, AttributeError) as e:
                    # Yükleme hatası durumunda mesaj göster.
                    print(f"Kural yüklenirken hata: {file} - {e}")

    def apply_rules(self, ast_tree, file_name, report_generator):
        """
        Yüklenen kuralları belirtilen AST üzerinde uygular.

        - ast_tree: Analiz edilecek soyut sözdizim ağacı.
        - file_name: Analiz edilen dosyanın adı.
        - report_generator: Rapor oluşturucu nesnesi.
        """
        # Kural yürütücüsü oluştur.
        rule_executor = RuleExecutor(report_generator, file_name)
        for rule in self.rules:
            rule_executor.execute_rule(rule, ast_tree)  # Her kuralı AST üzerinde çalıştır.
