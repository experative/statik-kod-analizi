import ast  # Soyut sözdizim ağacını analiz etmek için kullanılan modül.
from reports.report import Report  # Rapor oluşturmak için kullanılan sınıf.

class UnusedVariableRule:
    def apply(self, ast_tree, file_name, report_generator):
        """
        Kullanılmayan değişkenleri tespit eden kural:
        - Atanan ama kullanılmayan değişkenleri bulur.
        """
        assigned_vars = set()  # Atanan değişkenlerin listesi.
        used_vars = set()  # Kullanılan değişkenlerin listesi.
        builtins = dir(__builtins__)  # Dahili Python fonksiyon ve değişkenleri.

        for node in ast.walk(ast_tree):  # Tüm düğümleri dolaşır.
            if isinstance(node, ast.Assign):  # Değişken ataması kontrol edilir.
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(target.ctx, ast.Store):  # Değişken depolandıysa.
                        assigned_vars.add(target.id)  # Atanan değişkenler listesine ekle.

            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):  # Değişken kullanımı kontrol edilir.
                used_vars.add(node.id)  # Kullanılan değişkenler listesine ekle.

        unused_vars = assigned_vars - used_vars - set(builtins)  # Kullanılmayan değişkenleri belirle.
        for var in unused_vars:
            warning_message = f"Değişken '{var}' atanmış ama hiç kullanılmamış."  # Uyarı mesajı.
            print(warning_message)  # Konsola yazdır.

            # Rapor oluşturur ve raporlayıcıya ekler.
            report = Report(
                file_name=file_name,
                rule_type="unused_variable",
                message=warning_message
            )
            report_generator.add_report(report)  # Raporu ekle.
