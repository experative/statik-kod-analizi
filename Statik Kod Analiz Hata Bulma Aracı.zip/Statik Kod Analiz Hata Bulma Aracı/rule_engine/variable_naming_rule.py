import ast  # Soyut sözdizim ağacını analiz etmek için kullanılan modül.
from reports.report import Report  # Rapor oluşturmak için kullanılan sınıf.

class VariableNamingConventionRule:
    def apply(self, ast_tree, file_name, report_generator):
        """
        Değişken adlandırma kurallarını kontrol eden kural:
        - Değişkenler snake_case formatında olmalı.
        """
        builtins = dir(__builtins__)  # Dahili Python fonksiyon ve değişkenleri.

        for node in ast.walk(ast_tree):  # Tüm düğümleri dolaşır.
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):  # Değişken ataması kontrol edilir.
                # Değişken adı küçük harf veya büyük harf değilse ve dahili fonksiyon değilse:
                if not node.id.islower() and not node.id.isupper():
                    if node.id not in builtins:
                        warning_message = f"Değişken '{node.id}' snake_case adlandırma kuralına uymuyor."  # Uyarı mesajı.
                        print(warning_message)  # Konsola yazdır.

                        # Rapor oluşturur ve raporlayıcıya ekler.
                        report = Report(
                            file_name=file_name,
                            rule_type="variable_naming_convention",
                            message=warning_message,
                            line_number=node.lineno
                        )
                        report_generator.add_report(report)  # Raporu ekler.
