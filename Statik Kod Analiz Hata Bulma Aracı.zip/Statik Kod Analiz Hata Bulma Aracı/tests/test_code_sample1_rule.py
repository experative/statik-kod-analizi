def simple_function():
    X = 10  # VariableNamingRule hatası: 'X' değişkeni snake_case olmalı
    return X

def complex_function(a, b):
    if a > b:
        for i in range(b):
            if i % 2 == 0:
                try:
                    x = 1 / i  # VariableNamingRule hatası: 'x' değişkeni snake_case olmalı
                except ZeroDivisionError:
                    x = 0  # VariableNamingRule hatası: 'x' değişkeni snake_case olmalı
    else:
        while a < b:
            a += 1
            if a == b:
                break

def long_function():
    for i in range(10):
        print(i)
    # Some comment here
    # Another comment line
    for j in range(20):
        print(j)

def bool_op_function():
    if (A and b) or (c and d):  # VariableNamingRule hatası: 'A' değişkeni snake_case olmalı
        print("BoolOp Test")

# Ekstra VariableNamingRule hatası
userName = "John"  # VariableNamingRule hatası: 'userName' camelCase, snake_case olmalı
userAge = 30  # VariableNamingRule hatası: 'userAge' camelCase, snake_case olmalı
